#include "Registro.h"
using namespace std;

Registro::Registro(string mes, int dia, int horas, int minutos, int segundos,string ip,string problema) {

  dateStruct.tm_sec = segundos;
  dateStruct.tm_min = minutos;
  dateStruct.tm_hour = horas;
  dateStruct.tm_mday = dia;
  for (int i=0; i < meses.size(); i++) {
    if (meses[i]==mes)
      dateStruct.tm_mon = i;
  }
  dateStruct.tm_year = 2021 - 1900;  
  date = mktime(&dateStruct);
  month=mes;
  day=dia;
  hour=horas;
  minutes=minutos;
  seconds=segundos;
  problem=problema;
  ip1=ip;
}

Registro::Registro(std::string mes, int dia, int horas, int minutos, int segundos) {

  dateStruct.tm_sec = segundos;
  dateStruct.tm_min = minutos;
  dateStruct.tm_hour = horas;
  dateStruct.tm_mday = dia;
  for (int i=0; i < meses.size(); i++) {
    if (meses[i]==mes)
      dateStruct.tm_mon = i;
  }
  dateStruct.tm_year = 2021 - 1900;   
  date = mktime(&dateStruct);
}


//Diferentes tipos de impresion

void Registro::ImpresionNormal(){  
cout<<month<<" "<<day<<" "<<hour<<":"<<minutes<<":"<<seconds<<" "<<ip1<<" "<<problem<<endl;
}
void Registro::ImpresionTimet(){  
cout<<date<<" "<<ip1<<" "<<problem<<endl;
}

//Regresar datos priv
time_t Registro::getDate() {
  return date;
}

