/*Programa para ordenar de manera creciente el documento de bitacora por la fecha,y busqueda de un rango de fechas .

Pablo Gutierrez Costales  A01275119
creacion y ultima modificación 24 septiembre 2021*/


#include <iostream>
#include "Registro.h"
#include <fstream>
#include <vector>
#include<sstream>
#include <string>
using namespace std;


void docLectura(vector<Registro> &vector);

void docEscritura(vector<Registro> &vector);

void imprimir(vector<Registro> vector,int inicio,int fin);

void quicksort(vector<Registro> &vector,int ini, int ult);

int  binary(vector<Registro> vector,int k);



int main(){  
 //Creacion de Vector de Datos
  int busqueda1,busqueda2,d1,d2,h1,h2,min1,min2,s1,s2;
   string m1,m2;
  vector <Registro> vector;

  docLectura(vector);
 //Lectura de txt para llenar el vector todavia no jala XD
 //modificar bien el get.date()
  quicksort(vector,0,vector.size()-1); 

  docEscritura(vector);



  cout<<"Agrega Mes del la Busqueda inicial "<<endl;
  cin>>m1;
  cout<<"Agrega día del la Busqueda inicial "<<endl;
  cin>>d1;
  cout<<"Agrega hora del la Busqueda inicial "<<endl;
  cin>>h1;
  cout<<"Agrega minutos del la Busqueda inicial "<<endl;
  cin>>min1;
  cout<<"Agrega segundos del la Busqueda inicial "<<endl;
  cin>>s1;
  cout<<"Agrega Mes del la Busqueda Final "<<endl;
  cin>>m2;
  cout<<"Agrega día del la Busqueda Final "<<endl;
  cin>>d2;
  cout<<"Agrega hora del la Busqueda Final "<<endl;
  cin>>h2;
  cout<<"Agrega minutos del la Busqueda Final "<<endl;
  cin>>min2;
  cout<<"Agrega segundos del la Busqueda Final "<<endl;
  cin>>s2;
 
  Registro inicial(m1,d1,h1,min1,s1);
  Registro   final1(m2,d2,h2,min2,s2);

  busqueda1=binary(vector,inicial.getDate());
  busqueda2=binary(vector,final1.getDate());

  imprimir(vector,busqueda1,busqueda2);
}

//Agoritmo de ordenamiento
//vector de clases,inicio y final del vector
void quicksort(vector<Registro> &vector,int primero, int ultimo){
  int central,i,j,pivote;
  //creacion de pivote
  central=(primero+ultimo)/2;
   pivote=vector[central].getDate();
   
  int pibote = vector[central].getDate();

  i=primero;
  j=ultimo;
  
 do{
   //busqueda de datos no ordenados
  while(vector[i].date<pibote){i++;}
  while(vector[j].date>pibote){j--;}
 if(i<=j){
   //Intercambio los Valoes
   Registro aux=vector[i];
   vector[i]= vector[j];
   vector[j]=aux;
   i++;
   j--;

 }
 }
 while(i<=j);
//recursividad
 if(primero<j){
   quicksort(vector,primero,j);
 }
 if(i<ultimo){
   quicksort(vector,i,ultimo);
 }
 
}

//Agoritmo de busqueda binaria
//vector de clases,numero a buscar
//valor de reotno :ubicacion del numero dentro del vector o -1 si no fu encontrado
int binary(vector<Registro> vector,int k) {
  int prom,g,s;
  g=vector.size()-1;
  s=0;

  while (s<=g) {
   prom =s+ (g-s) / 2;
   if (vector[prom].getDate() == k) {  
     return prom;
          }
   else if (vector[prom].getDate() < k) {
     s= prom+1;
         }
   else if (vector[prom].getDate() > k) {
     g= prom-1;
          }
      }

    return -1;
}

//Impresion del rango de datos seleccionados
//Recibe el valor vector de clases,con el inicio y final de rango a imprimir
void imprimir(vector<Registro> vector,int inicio,int fin){
  int x;
  if (inicio==-1||fin==-1){
    cout<<"No se a encontrado una de las fechas seleccionadas"<<endl;
    exit(5);
  }
  cout<<"¿Cómo desea que se guarde la fecha en la bitacora BitacoraOrdenada.txt"<<endl;
   cout<<"1-Formato en segundos"<<endl;
   cout<<"2-Formato mes,dia,hora"<<endl;
   cin>>x;
   cout<<"Imprimiendo valores en el Rango solicitado"<<endl<<endl;
   if(x==1){
    for (int i = inicio; i <= fin; i++) {  
    vector[i].ImpresionTimet();
    }}
   else{
      for (int i =inicio; i <= fin; i++) {
       vector[i].ImpresionNormal();
   }
   }
}

//Lectura del documento txt y convierte la informacion en clases
//Recibe el valor vector donde se almacenara las clases 
void docLectura(vector<Registro> &vector) {
  
    int dia,hora,minutos,segundos;
string mes,ip,problema,diastring,horastring,minutosstring,segundostring,conv;
//Lectura Y comprobacion del documento
    ifstream dataD;    
    dataD.open("bitacora.txt", ios::in);
  if (dataD.fail()) {
        cout << "No se a podido leer el archivo txt";
        exit(1);
    }
  //Lectura y creacion de las clases
    while(getline(dataD, conv)){
      stringstream ss(conv);

      getline(ss,mes,' ');
      getline(ss,diastring,' ');
      getline(ss,horastring,':');
      getline(ss,minutosstring,':');
      getline(ss,segundostring,' ');
      getline(ss,ip,' ');
      getline(ss,problema);

        dia=stoi(diastring);
        hora=stoi(horastring);
        minutos=stoi(minutosstring);
        segundos=stoi(segundostring);

      vector.push_back(Registro(mes,dia, hora,minutos,segundos,ip,problema));
     }
}

//Escritura del documento txt con los datos ya ordenados
//Recibe el valor vector donde se almaceno la informacion
void docEscritura(vector<Registro> &vector){
//Comprobacion dee creacion de txt
    ofstream dataO("bitacora_ordenada.txt", ios::out);
    int x;
    if (dataO.fail()) {
        cout << "No se a podido crear el archivo de los datos ordenados";
        exit(1);
    }
//Opcion de guarda datos como segundos o formato hh/mm/ss
   cout<<"¿Cómo desea que se guarde la fecha en la bitacora BitacoraOrdenada.txt"<<endl;
   cout<<"1-Formato en segundos"<<endl;
   cout<<"2-Formato mes,dia,hora"<<endl;
   cin>>x;
   if(x==1){
    for (int i = 0; i < vector.size(); i++) {
        Registro x =  vector[i];
        dataO <<x.getDate() << " " << x.ip1 << " " << x.problem << endl;

    }
     cout<<"Se a guardado con exito los datos "<<endl;
   }
   else{
      for (int i = 0; i < vector.size(); i++) {
        Registro x =  vector[i];
        dataO << x.month << " " << x.day << " " << x.hour << ":" << x.minutes << ":" << x.seconds << " " << x.ip1 << " " << x.problem << endl;
        
       
   }
    cout<<"Se a guardado con exito los datos "<<endl;
    }
   
    dataO.close();
}
